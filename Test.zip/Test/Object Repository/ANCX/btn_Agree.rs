<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Agree</name>
   <tag></tag>
   <elementGuidId>471ebebf-e91c-4e06-9d82-4d09a49f74ce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[contains(.,'I AGREE!')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//button[@class='uc-btn-agree-cookie']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@class='uc-btn-agree-cookie']</value>
   </webElementProperties>
</WebElementEntity>
