<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Agree</name>
   <tag></tag>
   <elementGuidId>c0cdc687-1463-49bf-b665-b09fc29b57e2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@class='uc-btn-agree-cookie']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[contains(.,'I AGREE!')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@class='uc-btn-agree-cookie']</value>
   </webElementProperties>
</WebElementEntity>
